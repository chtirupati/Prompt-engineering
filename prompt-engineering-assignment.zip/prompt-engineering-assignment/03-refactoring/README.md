# Module 3 – Refactoring

## Target file

- `EmployeeList.messy.tsx`

## Task

Refactor the employee list while preserving existing behavior.

## Constraints

- Do not add new features.
- Preserve loading, empty, edit, and delete behavior.
- Keep the existing visual design and Redux integration.
- Handle loading, empty-state, and confirmation-before-delete edge cases.

## Deliverable

Provide a refactored standalone copy of `EmployeeList.messy.tsx` with an explanation of the changes.
