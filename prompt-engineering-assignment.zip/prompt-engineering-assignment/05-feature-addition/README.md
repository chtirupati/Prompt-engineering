# Module 5 – Feature Addition

## Target file

- `EmployeeList.tsx`

## Feature request

Add a search/filter box above the employee table. The box should filter rows by employee name or department.

## Task

The assistant must first decide where filtering state belongs and explain the Redux and local-component design, then implement the feature.

## Acceptance criteria

- Existing CRUD behavior remains intact.
- Search works for name or department.
- Filtering state can remain local to `EmployeeList`.
- Add an appropriate empty state for no matching employees.
- Run a build after implementation.
