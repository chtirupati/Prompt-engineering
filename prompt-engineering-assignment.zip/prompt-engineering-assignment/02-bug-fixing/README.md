# Module 2 – Bug Fixing

## Target file

- `employeeApi.buggy.ts`

## Task

Use an AI assistant to find the root cause of bugs and explain the fix before applying it.

## Deliverable

A buggy standalone copy of `employeeApi.ts` and a description of the bug causes and fixes.

## Prompt

Without reading the file first, hand the assistant only the target file. Ask it to find the root cause, explain why each bug occurs, apply the fix, and verify the implementation.
