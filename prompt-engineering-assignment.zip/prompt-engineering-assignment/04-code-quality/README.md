# Module 4 – Code Quality

## Target file

- `employeesSlice.quality.ts`

## Task

Review the employee Redux slice for type safety and error-handling quality.

## Quality requirements

- Explain why each change is needed.
- Keep current Redux behavior intact.
- Add or improve loading and error handling.
- Apply fixes only after the assistant understands the file.

## Deliverable

A standalone copy of the reviewed slice and a concise change list.
