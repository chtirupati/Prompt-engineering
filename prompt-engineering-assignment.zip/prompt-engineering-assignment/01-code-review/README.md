# Module 1 – Code Review

## Target file

- `EmployeeForm.review.tsx`

## Task

Ask an AI assistant to review `EmployeeForm.review.tsx` and identify accessibility, correctness, and maintainability issues.

## Deliverable

A standalone copy of the employee form should be placed in this folder for code review.

## Prompt

Review the employee form thoroughly. Do not edit the file. Identify:

1. Accessibility issues.
2. Form correctness issues.
3. Maintainability issues.
4. The top three prioritized issues.
